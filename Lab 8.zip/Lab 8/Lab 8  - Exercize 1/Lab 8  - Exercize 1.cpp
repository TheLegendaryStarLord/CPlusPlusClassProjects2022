/*************************************************************************
Cuyamaca College CS-181

File name:	Lab 7 - Exercise 1.cpp

Description: Lab 7, Exercise 1, Brief description of exercise

Developer: Adam Sanchez


*************************************************************************/
#include <cstring>
#include <iostream>
#include <string>
using namespace std;

int findVowels(char*);
int findConsonants(char*);

int main() {
    char Prompt[100], Option;

    // Ask the user to enter a string
    cout << "Enter a string:";
    cin.getline(Prompt, 100);

    // Process
    do {
        // Menu Display
        cout << "A) Count the number of vowels in the string\n";
        cout << "B) Count the number of consonants in the string\n";
        cout << "C) Count both the vowels and consonants in the string\n";
        cout << "D) Enter another string\n";
        cout << "E) Exit the program\n";
        cin >> Option;
        Option = toupper(Option);

        // Option Outputs
        switch (Option) {
        case 'A':
            cout << "There are " << findVowels(Prompt) << " vowels in the string:\n";
            break;
        case 'B':
            cout << "There are " << findConsonants(Prompt)
                << " consonants in the string:\n";
            break;
        case 'C':
            cout << "There are " << findConsonants(Prompt) << " consonants and "
                << findVowels(Prompt) << " vowels in the string\n";
            break;
            // Restart Program
        case 'D':
            cout << "Enter another string: ";
            cin.ignore();
            cin.getline(Prompt, 100);
        }

    } while (Option != 'E');

    // end of program
    cout << "Goodbye!";
}

/**********************************************************************
Function name: findVowels()

Purpose: 		Search for Vowels and count how many there are

Inputs: 		char* P - its short for Prompt, the CString input by
user

Returns: 		int Vowels - Number of vowels in Prompt

Revision history
Date		By			Description
------------------------------------------------------------------------
11/07/2022	Adam Sanchez		Created

************************************************************************/

int findVowels(char* P) {
    int Vowels = 0;

    for (int i = 0; i < strlen(P); i++) {
        if (toupper(P[i]) == 'A' || toupper(P[i]) == 'E' || toupper(P[i]) == 'I' ||
            toupper(P[i]) == 'O' || toupper(P[i]) == 'U')
            Vowels++;
    }

    return Vowels;
}

/**********************************************************************
Function name: findConsonants()

Purpose: 		Search for Consonants and count how many there are

Inputs: 		char* P - its short for Prompt, the CString input by
user

Returns: 		int Cons - Number of Consonants in Prompt

Revision history
Date		By			Description
------------------------------------------------------------------------
11/07/2022	Adam Sanchez		Created

************************************************************************/
int findConsonants(char* P) {
    int Cons = 0;

    for (int i = 0; i < strlen(P); i++) {
        if (isalpha(P[i]))
            Cons++;
    }

    return Cons - findVowels(P);
}