/*************************************************************************
Cuyamaca College CS-181

File name:	Lab 9 - Exercise 1.cpp

Description: Lab 9, Exercise 1, a program that uses a structure named corpSales to store data about a company division and report total and average
 

Developer: Adam Sanchez


*************************************************************************/

#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

struct corpSales{
    string Division;
    double SalesQ1;
    double SalesQ2;
    double SalesQ3;
    double SalesQ4;
    double TotalAnnualSales;
    double AvgQuarterlySales;;
};

int main()
{
    corpSales corp1;
    corpSales corp2;

    corp1.Division = "East";
    corp2.Division = "West";

    //Corp1
    cout << "Enter the quarterly sales for the " << corp1.Division << " Division:" << endl;
    cout << "\tFirst Quarter: $";
    cin >> corp1.SalesQ1;

    cout << "\tSecond Quarter: $";
    cin >> corp1.SalesQ2;

    cout << "\tThird Quarter: $";
    cin >> corp1.SalesQ3;

    cout << "\tFourth Quarter: $";
    cin >> corp1.SalesQ4;

    corp1.TotalAnnualSales = corp1.SalesQ1 + corp1.SalesQ2 + corp1.SalesQ3 + corp1.SalesQ4;
    corp1.AvgQuarterlySales = corp1.TotalAnnualSales / 4;

    //Corp2
    cout << "Enter the quarterly sales for the " << corp2.Division << " Division:" << endl;
    cout << "\tFirst Quarter: $";
    cin >> corp2.SalesQ1;

    cout << "\tSecond Quarter: $";
    cin >> corp2.SalesQ2;

    cout << "\tThird Quarter: $";
    cin >> corp2.SalesQ3;

    cout << "\tFourth Quarter: $";
    cin >> corp2.SalesQ4;

    corp2.TotalAnnualSales = corp2.SalesQ1 + corp2.SalesQ2 + corp2.SalesQ3 + corp2.SalesQ4;
    corp2.AvgQuarterlySales = corp2.TotalAnnualSales / 4;

    //Display Total and Average sales
    cout << "Total Annual Sales: " << endl;
    cout << "\t" << corp1.Division << " Division: $" << fixed << setprecision(2) << corp1.TotalAnnualSales << endl;
    cout << "\t" << corp2.Division << " Division: $" << fixed << setprecision(2) << corp2.TotalAnnualSales << endl;

    cout << "Avereage Quarterly Sales: " << endl;
    cout << "\t" << corp1.Division << " Division: $" << fixed << setprecision(2) << corp1.AvgQuarterlySales << endl;
    cout << "\t" << corp2.Division << " Division: $" << fixed << setprecision(2) << corp2.AvgQuarterlySales << endl;
}