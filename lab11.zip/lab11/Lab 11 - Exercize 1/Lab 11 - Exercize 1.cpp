/*************************************************************************
Cuyamaca College CS-181

File name:	Lab 11 - Exercise 1.cpp

Description: Lab 11, Exercise 1, Creates a car using classes,
                                 accelerates then brakes
                                 asks to restart

Developer: Adam Sanchez


*************************************************************************/

#include <iostream>
#include <string>
using namespace std;

/*
 Class car - test constructors, setters, getters and other methods with car information
*/
class car
{
    private:
        int yearModel;
        string make;
        int speed = 0;

    public:

        /*
         car() - constructor 1
        */
        car() {
            yearModel = 0;
            make = "Dne";
        }

        /*
         car() - constructor 2
        */
        car(int inYearModel) {
            yearModel = inYearModel;
            make = "Undefined";
        }

        /*
         car() - constructor 3
        */
        car(int inYearModel, string inMake) {
            yearModel = inYearModel;
            make = inMake;
        }

        /*
         setYear() - sets the year model of the car
         @param inYearModel - input of the year model
        */
        void setYear(int inYearModel) {
            yearModel = inYearModel;
        }

        /*
         getYear() - gets the year of the model
         @return - the year of the model
        */
        int getYear() {
            return yearModel;
        }

        /*
         setMake() - sets the make of the car
         @param inMake - input make of the car
        */
        void setMake(string inMake) {
            make = inMake;
        }

        /*
         getMake() - get the make of the car
         @return make - the make of the car
        */
        string getMake() {
            return make;
        }

        /*
         accelerate() - accelerates the speed of the car by 5
        */
        void accelerate() {
            cout << "accelerating..." << endl;
            speed += 5;
            cout << "Current Speed: " << speed << endl;
        }

        /*
         brake() - decelerates the speed of the car by 5
        */
        void brake() {
            cout << "hitting the brakes..." << endl;
            speed -= 5;
            cout << "Current Speed: " << speed << endl;
        }
};


int main()
{
    char restart;
    string make;
    int year;

    do {
        //input information
        cout << "Please enter the Year and Model, (1990 Nissan Skyline): ";
        cin >> year;
        getline(cin, make, '\n');

        //creates the car
        car car1(year, make);

        //displays car information
        cout << "Current Car: " << car1.getYear() << car1.getMake() << endl;

        //speeds and slows down
        for (int i = 0; i < 5; i++) {
            car1.accelerate();
        }
        for (int i = 0; i < 5; i++) {
            car1.brake();
        }
        
        //asks to input another car
        cin.clear();
        cout << "would you like to enter a different car? Y or N: ";
        cin >> restart;

    } while (restart == 'y' || restart == 'Y');
}
