/*************************************************************************
Cuyamaca College CS-181

File name:	lab13-Inheritance.cpp

Description: Lab 13, Exercise 1, creates ProductionWorker object through inheritance and displays info in string

Developer: Adam Sanchez


*************************************************************************/

using namespace std;
#include <iomanip>
#include <string>
#include <iostream>
#include <sstream>

class Employee {

protected:
    string empName;
    string empNumber;
    string hireDate;

public:

    //Default Constructor
    Employee() {
        empName = "no name";
        empNumber = "000";
        hireDate = "0/0/0";
    }
    
    //Param constructor
    Employee(string inName, string inNum, string inDate) {
        empName = inName;
        empNumber = inNum;
        hireDate = inDate;
    }

    //gets the name
    string getName() {
        return empName;
    }

    //setter for name
    void setName(string inName) {
        empName = inName;
    }

    //getter for the employee number
    string getNum() {
        return empNumber;
    }

    //setter for the employee number
    void setNum(string inNum) {
        empNumber = inNum;
    }

    //getter for the date
    string getDate() {
        return hireDate;
    }

    //setter for the date
    void setDate(string inDate) {
        hireDate = inDate;
    }

};

class ProductionWorker : public Employee {

protected:
    int shiftNum;
    double hrPayRt;

public:

    //default constructor for ProductionWorker with employee
    ProductionWorker() : Employee() {
        shiftNum = 0;
        hrPayRt = 0.0;
    }
    
    //param constructor for ProductionWorker with employee
    ProductionWorker(string inName, string inNum, string inDate, int inShift, double inPayRt) : Employee(inName, inNum, inDate) {
        shiftNum = inShift;
        hrPayRt = inPayRt;
    }
    
    //setter for shift number
    void setShiftNum(int inShift) {
        shiftNum = inShift;
    }

    //getter for the shift number
    int getShiftNum() {
        return shiftNum;
    }

    //getter for the shift(Day or Night)
    string getShift() {
        string shift = "";
        if (shiftNum == 1) {
            shift = "Day";
        }
        else if (shiftNum == 2) {
            shift = "Night";
        }
        else {
            shift = "unknown";
        }

        return shift;
    }

    //setter for the pay rate
    void setPayRt(int inPayRt) {
        hrPayRt = inPayRt;
    }

    //getter for pay rate
    double getPayRt() {
        return hrPayRt;
    }

    //Converts information into string format
    friend ostream& operator<<(ostream& out, ProductionWorker a) {
        out << "Name: " << a.getName() << "\nEmployee Number: " << a.getNum() << "\nHireDate: " << a.getDate() << "\nShift: " << a.getShift() << "\nShift Number: " << a.getShiftNum() << "\nPay Rate: " << setprecision(2) << fixed << a.getPayRt() << endl;
        return out;
    }

    //displays information of the ProductionWorker object in string
    string toString(ProductionWorker a) {
        ostringstream ss;
        ss << a;
        return ss.str();
    }
};

int main()
{
    ProductionWorker pw("John Smith", "123", "10/12/2010", 2, 18.00);
    cout << pw.toString(pw);
}

