/*************************************************************************
Cuyamaca College CS-181

File name:	Numbers.h

Description: Lab 12, Exercise 1, predefines the value for NumbersClass

Developer: Adam Sanchez


*************************************************************************/

#ifndef Numbers_h
#define Numbers_h

class Numbers {
private:
	int number;
	static std::string lessThan20[20];
	static std::string lessThan100[];
	static std::string hundred;
	static std::string thousand;
public:
	Numbers();
	Numbers(int);
	void print();
};
#endif // !Numbers_h

