/*************************************************************************
Cuyamaca College CS-181

File name:	Lab12-NumberClass.cpp

Description: Lab 12, Exercise 1, Converts numerical values into english

Developer: Adam Sanchez


*************************************************************************/

#include <iostream>
#include "Numbers.h"
using namespace std;

/*
English words
*/
string Numbers::lessThan20[] = { "zero","one","two","three","four","five", "six", "seven", "eight", "nine", "ten",
								"eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
								"eighteen", "nineteen" };
string Numbers::lessThan100[] = {"zero","ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };
string Numbers::hundred = "hundred";
string Numbers::thousand = "thousand";

/**********************************************************************
Consstructor name:	Numbers()

Purpose: 		default constructor for Numbers

Inputs: 		none

Returns: 		Void

Revision history
Date		By			Description
------------------------------------------------------------------------
12/5/2022	Adam Sanchez		Created

************************************************************************/
Numbers::Numbers() {
	number = 0;
}

/**********************************************************************
Consstructor name:	Numbers()

Purpose: 		input constructor for Numbers

Inputs: 		Int num - the inputted number

Returns: 		Void

Revision history
Date		By			Description
------------------------------------------------------------------------
12/5/2022	Adam Sanchez		Created

************************************************************************/
Numbers::Numbers(int num) {
	number = num;
}

/**********************************************************************
Class function name:	print()

Purpose: 		translates the numerical values to english

Inputs: 		None

Returns: 		Void

Revision history
Date		By			Description
------------------------------------------------------------------------
12/5/2022	Adam Sanchez		Created

************************************************************************/
void Numbers::print() {
	int residue;
	if (number < 0) {
		cout << "number is negative. Please re-enter a positive number.";
	}
	number = abs(number);
	residue = number / 1000;

	cout << "The english translation is: ";

	if (residue > 0) {
		cout << lessThan20[residue] << " " << thousand << " ";
	}
	number %= 1000;
	residue = number / 100;

	if (residue > 0) {
		cout << lessThan20[residue] << " " << hundred << " ";
	}
	number %= 100;
	if (number >= 20) {
		residue = number / 10;
		if (residue > 0) {
			cout << lessThan100[residue] << " ";
		}
	}
	else if (number >= 10)
	{
		cout << lessThan20[number] << " ";

		return;
	}
	number %= 10;
	if (number > 0) {
		cout << lessThan20[number];
	}
	cout << "";
}


/*
Main
*/
int main()
{
	int number = 0;
	cout << "This program translates whole dollar amounts\n";
	cout << "from 0 to 9999 into an english translation.\n\n";
	cout << "please enter a number from 0 - 9999: ";
	cin >> number;

	Numbers run(number);

	if (number >= 0 && number <= 9999) {
		run.print();
	}
}