/*************************************************************************
Cuyamaca College CS-181

File name:	fileName.cpp

Description: Lab 10, Exercise 1, opens a file and counts each line, pausing for each 24 lines

Developer: Adam Sanchez


*************************************************************************/

#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
using namespace std;

bool openFileIn(ifstream&, string);
void processFile(ifstream&, string);

int main() {
    string nameFile, line;
    ifstream dataFile;

    cout << "Please enter name of file: ";
    cin >> nameFile;
    cin.ignore();

    if (openFileIn(dataFile, nameFile)) {
        cout << "File has been opened!" << endl;
        cout << "Processing data in file...\n" << endl;
        processFile(dataFile, line);
        dataFile.close();
        cout << "======================\n"
            << "File has been closed\nSearching for File #2" << endl;
    }
    else {
        cout << "File has not been found";
    }

    cout << "Please enter name of file: ";
    cin >> nameFile;
    cin.ignore();

    if (openFileIn(dataFile, nameFile)) {
        cout << "File has been opened!" << endl;
        cout << "Processing data in file...\n" << endl;
        processFile(dataFile, line);
        dataFile.close();
        cout << "======================\n"
            << "File has been closed" << endl;
    }
    else {
        cout << "File has not been found";
    }
}

/**********************************************************************
Function name:	openFileIn()

Purpose: 		Searches for the file and opens if found

Inputs: 		file - the file object holding the file being used, nameOfFile - the name of the file to be searched

Returns: 		bool

Revision history
Date		By			Description
------------------------------------------------------------------------
11/12/2022	Adam Sanchez		Created

************************************************************************/
bool openFileIn(ifstream& file, string nameOfFile) {
    file.open(nameOfFile, ios::in);
    if (file.fail()) {
        cout << "This file does not exist" << endl;
        return false;
    }
    else {
        cout << "This file does exist" << endl;
        return true;
    }
}

/**********************************************************************
Function name:	processFile()

Purpose: 		prints out the file line by line, counting each line, and pauses for every 24 lines 

Inputs: 		file - the file object holding the file being used, line - the line string object on the file

Returns: 		void

Revision history
Date		By			Description
------------------------------------------------------------------------
11/12/2022	Adam Sanchez		Created

************************************************************************/
void processFile(ifstream& file, string line) {
    int linecounter = 0;
    int lineLimit = 24;

    cout << "===================" << endl;

    while (getline(file, line)) {
        linecounter++;
        cout << linecounter << ":" << line << endl;

        if (linecounter == lineLimit) {
            cout << "Please press Enter to continue...";
            cin.get();
        }
    }
}
